@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "SCRIPT=%SCRIPT_DIR%Enable-ClientSshSupport.ps1"

if not exist "%SCRIPT%" (
  echo Could not find "%SCRIPT%".
  echo Keep this .bat file in the same folder as Enable-ClientSshSupport.ps1.
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
pause
