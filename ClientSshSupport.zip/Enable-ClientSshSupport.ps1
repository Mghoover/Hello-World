#Requires -RunAsAdministrator
<#
Client SSH support bootstrap for Windows.

What it does:
- Installs/enables Microsoft OpenSSH Server.
- Starts sshd and enables it at boot.
- Enables the built-in "OpenSSH SSH Server" firewall rule.
- Creates a temporary Ed25519 keypair.
- Adds the temporary public key to the chosen Windows user's authorized_keys.
- Writes a copy/paste support token to the current user's Desktop.

Treat the token like a temporary password. Anyone with it can SSH as the
selected Windows account until the authorized key is removed.
#>

[CmdletBinding()]
param(
    [string]$TargetUser = $env:USERNAME,
    [int]$ExpiresInHours = 24
)

$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Run this script from an elevated PowerShell window: right-click PowerShell, then choose 'Run as administrator'."
    }
}

function Get-LocalUserProfilePath {
    param([Parameter(Mandatory)][string]$UserName)

    $localUser = Get-LocalUser -Name $UserName -ErrorAction Stop
    $sid = $localUser.SID.Value
    $profile = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$sid" -ErrorAction Stop
    if (-not $profile.ProfileImagePath) {
        throw "Could not find a Windows profile path for user '$UserName'."
    }
    return [Environment]::ExpandEnvironmentVariables($profile.ProfileImagePath)
}

function Set-StrictFileAcl {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$UserName
    )

    $acl = Get-Acl -LiteralPath $Path
    $acl.SetAccessRuleProtection($true, $false)

    foreach ($rule in @($acl.Access)) {
        [void]$acl.RemoveAccessRule($rule)
    }

    $systemRule = [System.Security.AccessControl.FileSystemAccessRule]::new(
        "SYSTEM",
        "FullControl",
        "Allow"
    )
    $adminsRule = [System.Security.AccessControl.FileSystemAccessRule]::new(
        "Administrators",
        "FullControl",
        "Allow"
    )
    $userRule = [System.Security.AccessControl.FileSystemAccessRule]::new(
        $UserName,
        "FullControl",
        "Allow"
    )

    $acl.AddAccessRule($systemRule)
    $acl.AddAccessRule($adminsRule)
    $acl.AddAccessRule($userRule)
    Set-Acl -LiteralPath $Path -AclObject $acl
}

function Test-LocalUserIsAdministrator {
    param([Parameter(Mandatory)][string]$UserName)

    $localUser = Get-LocalUser -Name $UserName -ErrorAction Stop
    $adminMembers = Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop
    return [bool]($adminMembers | Where-Object {
        $_.SID -and $_.SID.Value -eq $localUser.SID.Value
    })
}

Assert-Administrator

$sshServerCapability = Get-WindowsCapability -Online -Name "OpenSSH.Server~~~~0.0.1.0"
if ($sshServerCapability.State -ne "Installed") {
    Add-WindowsCapability -Online -Name "OpenSSH.Server~~~~0.0.1.0" | Out-Null
}

Set-Service -Name sshd -StartupType Automatic
Start-Service -Name sshd

if (Get-Service -Name ssh-agent -ErrorAction SilentlyContinue) {
    Set-Service -Name ssh-agent -StartupType Manual
}

$sshFirewallRules = Get-NetFirewallRule -Name "OpenSSH-Server-In-TCP" -ErrorAction SilentlyContinue
if ($sshFirewallRules) {
    $sshFirewallRules | Enable-NetFirewallRule
} else {
    New-NetFirewallRule `
        -Name "OpenSSH-Server-In-TCP" `
        -DisplayName "OpenSSH SSH Server" `
        -Enabled True `
        -Direction Inbound `
        -Protocol TCP `
        -Action Allow `
        -LocalPort 22 | Out-Null
}

$targetProfile = Get-LocalUserProfilePath -UserName $TargetUser
$sshDir = Join-Path $targetProfile ".ssh"
$authorizedKeys = Join-Path $sshDir "authorized_keys"

New-Item -ItemType Directory -Force -Path $sshDir | Out-Null
if (-not (Test-Path -LiteralPath $authorizedKeys)) {
    New-Item -ItemType File -Path $authorizedKeys | Out-Null
}

$supportRoot = Join-Path $env:ProgramData "RemoteSupportSSH"
New-Item -ItemType Directory -Force -Path $supportRoot | Out-Null

$supportId = "support-" + (Get-Date -Format "yyyyMMdd-HHmmss") + "-" + ([Guid]::NewGuid().ToString("N").Substring(0, 8))
$keyPath = Join-Path $supportRoot $supportId
$comment = "$supportId@$env:COMPUTERNAME"

& ssh-keygen.exe -q -t ed25519 -N "" -C $comment -f $keyPath
if ($LASTEXITCODE -ne 0) {
    throw "ssh-keygen failed with exit code $LASTEXITCODE."
}

$publicKey = Get-Content -LiteralPath "$keyPath.pub" -Raw
$isAdminUser = Test-LocalUserIsAdministrator -UserName $TargetUser

if ($isAdminUser) {
    $adminAuthorizedKeys = Join-Path $env:ProgramData "ssh\administrators_authorized_keys"
    if (-not (Test-Path -LiteralPath $adminAuthorizedKeys)) {
        New-Item -ItemType File -Force -Path $adminAuthorizedKeys | Out-Null
    }

    $existingAdminAuthorizedKeys = Get-Content -LiteralPath $adminAuthorizedKeys -Raw -ErrorAction SilentlyContinue
    if ($existingAdminAuthorizedKeys -notmatch [regex]::Escape($publicKey.Trim())) {
        Add-Content -LiteralPath $adminAuthorizedKeys -Value $publicKey.Trim()
    }

    icacls.exe $adminAuthorizedKeys /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F" | Out-Null
} else {
    $existingAuthorizedKeys = Get-Content -LiteralPath $authorizedKeys -Raw -ErrorAction SilentlyContinue
    if ($existingAuthorizedKeys -notmatch [regex]::Escape($publicKey.Trim())) {
        Add-Content -LiteralPath $authorizedKeys -Value $publicKey.Trim()
    }

    Set-StrictFileAcl -Path $sshDir -UserName $TargetUser
    Set-StrictFileAcl -Path $authorizedKeys -UserName $TargetUser
}

$privateKeyBase64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($keyPath))
$expiresAt = (Get-Date).AddHours($ExpiresInHours).ToString("yyyy-MM-dd HH:mm:ss zzz")
$desktop = [Environment]::GetFolderPath("Desktop")
$tokenPath = Join-Path $desktop "ssh-support-token-$env:COMPUTERNAME.txt"

$token = @"
SSH_SUPPORT_TOKEN_V1
ComputerName=$env:COMPUTERNAME
WindowsUser=$TargetUser
SupportId=$supportId
CreatedAt=$(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
ExpiresAt=$expiresAt
SshPort=22
PrivateKeyBase64=$privateKeyBase64

Send this whole file back to support.
If support asks for an address, send the Tailscale IP or DNS name for this computer too.

Cleanup after support is complete:
1. Open an elevated PowerShell window.
2. Run:
   `$ak = "$(if ($isAdminUser) { $adminAuthorizedKeys } else { $authorizedKeys })"
   `(Get-Content `$ak) | Where-Object { `$_ -notmatch "$supportId" } | Set-Content `$ak
   Remove-Item -Force "$keyPath", "$keyPath.pub" -ErrorAction SilentlyContinue
"@

Set-Content -LiteralPath $tokenPath -Value $token -Encoding ASCII

Write-Host ""
Write-Host "SSH support access is enabled." -ForegroundColor Green
Write-Host "Computer name: $env:COMPUTERNAME"
Write-Host "Windows user:  $TargetUser"
Write-Host "SSH port:      22"
Write-Host "Token file:    $tokenPath"
Write-Host ""
Write-Host "Send the token file to support, plus this computer's Tailscale IP or Tailscale DNS name."
Write-Host "Treat the token like a temporary password."
